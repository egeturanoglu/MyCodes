
import java.io.*;

public class DropShippingApp {
	
	/*
	 * This is our main method which we use to create neccesary objects to use in our program. 
	 * We create file objects with the paths of .csv files given in homework in order to use in methods.
	 * After that we call our SalesQuery class methods.
	 * 
	 */
	

	public static void main(String[] args) throws Exception {

		File customerFile = new File("src/Customers.csv");
		File supplier1ProductsFile = new File("src/S1_Products.csv");
		File supplier1SalesFile = new File("src/S1_Sales.csv");
		File supplier2ProductsFile = new File("src/S2_Products.csv");
		File supplier2SalesFile = new File("src/S2_Sales.csv");
		File supplier3ProductsFile = new File("src/S3_Products.csv");
		File supplier3SalesFile = new File("src/S3_Sales.csv");
		
		//We create a customer array using "Customer.csv" file.
		Customer[] customers = JavaIOFile.readAndCreateCustomers(customerFile);
		
		//We create supplier arrays using "S1_Products.csv, S2_Products.csv, S3_Products" files.
		Supplier sup1 = new Supplier(JavaIOFile.readAndCreateProducts(supplier1ProductsFile));
		Supplier sup2 = new Supplier(JavaIOFile.readAndCreateProducts(supplier2ProductsFile));
		Supplier sup3 = new Supplier(JavaIOFile.readAndCreateProducts(supplier3ProductsFile));
		
		//We create sales arrays using "S1_Sales.csv, S2_Sales.csv, S3_Sales.csv"
		Sales[] salesArr1 = JavaIOFile.readAndCreateSales(supplier1SalesFile);
		Sales[] salesArr2 = JavaIOFile.readAndCreateSales(supplier2SalesFile);
		Sales[] salesArr3 = JavaIOFile.readAndCreateSales(supplier3SalesFile);
		
		//Our Methods
		System.out.println(SalesQuery.mostProfitiable(sup1,sup2,sup3));
		System.out.println();
		System.out.println(SalesQuery.mostExpensive(sup1, sup2, sup3));
		System.out.println();
		System.out.println(SalesQuery.leastProfitS1(sup1));
		System.out.println();
		System.out.println(SalesQuery.totalProfit(sup1, sup2, sup3, salesArr1, salesArr2, salesArr3));
		System.out.println();
		System.out.println(SalesQuery.mostBuy(customers, salesArr1, salesArr2, salesArr3));
		
	
	}

}
