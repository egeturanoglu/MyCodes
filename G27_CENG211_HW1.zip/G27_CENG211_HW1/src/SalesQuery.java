import java.io.File;
import java.io.IOException;

public class SalesQuery {
	
	/*
	 * This is our SalesQuery class which we code the methods of the given definitions in the homework.
	 * All methods are static because it would be obscene and we do not need to create an SalesQuery
	 * object to use the methods.
	 */
	
	//Gives the most profitable product of the 3 suppliers.
	public static Product mostProfitiable(Supplier sup1, Supplier sup2, Supplier sup3) {
		
		Product mostProfitableProduct1 = sup1.getProduct()[0]; 
		Product mostProfitableProduct2 = sup2.getProduct()[0]; 
		Product mostProfitableProduct3 = sup3.getProduct()[0]; 
		
		Supplier[] suppliers = {sup1,sup2,sup3};
		
		//Most profitable product of each supplier.		
		for(int i = 0; i<suppliers[0].getProduct().length; i++) {
			if(profit(mostProfitableProduct1) < profit(suppliers[0].getProduct()[i])) {
				mostProfitableProduct1 = suppliers[0].getProduct()[i];
			}
		}
		
		for(int i = 0; i<suppliers[1].getProduct().length; i++) {
			if(profit(mostProfitableProduct1) < profit(suppliers[1].getProduct()[i])) {
				mostProfitableProduct1 = suppliers[1].getProduct()[i];
			}
		}
		
		for(int i = 0; i<suppliers[2].getProduct().length; i++) {
			if(profit(mostProfitableProduct1) < profit(suppliers[2].getProduct()[i])) {
				mostProfitableProduct1 = suppliers[2].getProduct()[i];
			}
		}
		//An array of every suppliers most profitable product. 
		Product[] profitableProducts = {mostProfitableProduct1,mostProfitableProduct2,mostProfitableProduct3};
		Product utmostProfitable = profitableProducts[0];
		
		//to find the utmost profitable product, it compares it with each suppliers most profitable product.
		for(int i=0; i<profitableProducts.length; i++) {
			if(profit(utmostProfitable) < profit(profitableProducts[i])) {
				utmostProfitable = profitableProducts[i];
			}
		}
		
		//RESULTS.
		System.out.println("The amount of profit of most profitable product: " + profit(utmostProfitable)+ "TL.");
		return utmostProfitable;	
	}
	
	/*
	 * 
	 */

	//Gives us the most Expensive product from supplier 1,2 and 3.
	public static Product mostExpensive(Supplier sup1, Supplier sup2, Supplier sup3) {
		
		Product mostExpensiveProduct = null;
 		int productNum = (sup1.getProduct().length)+(sup2.getProduct().length)+(sup3.getProduct().length); //calculates the total product number.
 		Product[] supProducts = new Product[productNum]; //The number of supplier prices is equal to the product number.  
 		double[] priceArray = new double[productNum];
 		 		
 		//All of the products in an single array.	
 		for(int i=0; i<sup1.getProduct().length; i++) {
 			supProducts[i] = sup1.getProduct()[i];
 		}
 		
 		for(int i=0; i<sup2.getProduct().length; i++) {
 			supProducts[i + sup1.getProduct().length] = sup2.getProduct()[i];
 		}
 		
 		for(int i=0; i<sup3.getProduct().length; i++) {
 			supProducts[i + sup1.getProduct().length + sup2.getProduct().length] = sup3.getProduct()[i];
 		}
 		
 		
 		//Check the prices and find the max.
 		for(int i=0; i<supProducts.length; i++) {
 			priceArray[i] = supProducts[i].getPrice();
 		}
 		for(int i=0; i<priceArray.length; i++) {
 			if(maxValueArray(priceArray) == supProducts[i].getPrice()) {
 				mostExpensiveProduct = supProducts[i];
 			}
 		}
 		
 		//RESULTS
 		System.out.println("Most expensive product is: " + maxValueArray(priceArray) + "TL.");
		return mostExpensiveProduct;
	}
	
	/*
	 * 
	 */
	
	//Gives the most frequent customer of the given sales arrays.
	public static Customer mostBuy(Customer[] customers,Sales[] sales1, Sales[] sales2, Sales[] sales3) {
			
		int totalSaleNum = sales1.length + sales2.length + sales3.length; 
		//Most frequent ID in the array is empty because it will be updated later.
		String arrayFrequentID = "";
		Customer mostFrequentCustomer = null;
	
		//An array of all the customer ID's
		String[] arrayID = new String[totalSaleNum];
		
		//We put all customer ID's in an array.
		for(int i=0; i<sales1.length; i++) {
			arrayID[i] = sales1[i].getCustomerID();
		}
		
		for(int i=0; i<sales2.length; i++) {
			arrayID[i + sales1.length] = sales2[i].getCustomerID();
		}
		
		for(int i=0; i<sales3.length; i++) {
			arrayID[i + sales1.length + sales2.length] = sales3[i].getCustomerID();
		}
		
		//find the most frequent ID in the array while printing the amount of the purchases made.
		arrayFrequentID = mostFrequentID(arrayID);
		
		//find the customer with the matching customer ID.
		for(int i=0; i<customers.length; i++) {
			if(arrayFrequentID.equalsIgnoreCase(arrayFrequentID)) {
				 mostFrequentCustomer = customers[i];
				 break;
				
			}
		}

		//RESULTS
		return mostFrequentCustomer;
	}
	
	
	/*
	 * 
	 */
	
	//Gives the least profitable product of supplier1 
	public static Product leastProfitS1(Supplier sup1) {
		
		Product leastProfitableProduct1 = sup1.getProduct()[0]; 
		
		//find the least profitable product.
		for(int i=0; i<sup1.getProduct().length; i++) {
				if(profit(leastProfitableProduct1) > profit(sup1.getProduct()[i])) {
					leastProfitableProduct1 = sup1.getProduct()[i];
			}
		}
		
		//RESULTS
		System.out.println("The amount of profit of least profitable product: " + profit(leastProfitableProduct1) +"TL.");
		return leastProfitableProduct1;
	}
	
	/*
	 * 
	 */
	
	//UNDER CONSTRACTION
	public static double totalProfit(Supplier sup1, Supplier sup2, Supplier sup3, Sales[] sales1, Sales[] sales2, Sales[] sales3) {
		double totalProfit = 0;
			
		//check every suppliers product end sales then calculate the profit.
		for(int i=0; i<sup1.getProduct().length; i++) {
			for(int j=0; j<sales1.length; j++) {
			if(sup1.getProduct()[i].getId().equals(sales1[j].getProductID())) {
				totalProfit = totalProfit + profit(sup1.getProduct()[i]);
			}
		}
	}
		
		for(int i=0; i<sup2.getProduct().length; i++) {
			for(int j=0; j<sales2.length; j++) {
			if(sup2.getProduct()[i].getId().equals(sales2[j].getProductID())) {
				totalProfit = totalProfit + profit(sup2.getProduct()[i]);
				
			}
		}
	}
		for(int i=0; i<sup3.getProduct().length; i++) {
			for(int j=0; j<sales3.length; j++) {
			if(sup3.getProduct()[i].getId().equals(sales3[j].getProductID())) {
				totalProfit = totalProfit + profit(sup3.getProduct()[i]);
				
			}
		}
	}
	
		//RESULTS
		System.out.print("Total profit is: ");
		return totalProfit;
	}
	
	/*
	 * 
	 */
	
	//Other Methods
	//Finds the max value in an array.
	private static double maxValueArray(double[] ar) {
		double maxValue = ar[0];
			for(int i = 0; i<ar.length; i++) {
				if(maxValue< ar[i]) {
					maxValue = ar[i];
				}
			}
		return maxValue;
	}
	
	//finds the profit of the given product.
	private static double profit(Product product) {
		double profit = (((product.getRate()/5.0)*100)*product.getNumberOfReviews());	
		return profit;
	}
	
	//Gives the most frequent ID(String) in the given array.
	//Also gives the amount of purchases made by that individual.
	private static String mostFrequentID(String[] arr) {
		int freq = 0;
		String result = "";
		
		for(int i=0; i<arr.length; i++) {
			int counter = 0;
			for(int j=i+1; j<arr.length; j++) {
				if(arr[j].equals(arr[i])) {
					counter++;
				}
			}
			if(counter >= freq) {
				result = arr[i];
				freq = counter;
			}
		}
		
		System.out.println("Most frequent customer made " + freq + " purchases.");
		return result;
		
		
	}
	
}
