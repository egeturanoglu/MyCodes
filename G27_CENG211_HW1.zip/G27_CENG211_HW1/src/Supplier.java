
public class Supplier {
	private Product[] product;

	//Default constructor
		public Supplier() {
			product = null;
		}
	
	//Defined constructor
	public Supplier(Product[] product) {
		this.product = product;
	}


	public Product[] getProduct() {
		return product;
	}


	
}
