
public class SalesManagement {

	private Sales[][] sales;

	//Default constructor
	public SalesManagement() {
		this.sales = null;
	}
	
	//Defined constructor
	public SalesManagement(Sales[][] sales) {
		this.sales = sales;
	}
	
	//Setters and Getters
	public Sales[][] getSales() {
		Sales[][] array = new Sales[sales.length][];
		for (int i = 0; i < sales.length; i++) {
			array[i] = sales[i];
		}
		return array;
	}
	
	
	
	
	

	
}
