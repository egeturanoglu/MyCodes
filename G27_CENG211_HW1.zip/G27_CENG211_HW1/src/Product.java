
public class Product {

	private String id;
	private String title;
	private double rate;
	private int numberOfReviews;
	private double price;
	private double salesPrice;
	
	//default constructor
		public Product() {
			id = "";
			title = "";
			rate = 0;
			numberOfReviews = 0;
			price = 0;
		}
	
	//defined constructor
	public Product(String id, String title, double rate, int numberOfReviews, double price) {
		this.id = id;
		this.title = title;
		this.rate = rate;
		this.numberOfReviews = numberOfReviews;
		this.price = price;
		this.salesPrice = price + (((rate/5.0)*100)*numberOfReviews);
	}

	
	public String getId() {
		return id;
	}
	public double getSalesPrice() {
		return salesPrice;
	}

	public String getTitle() {
		return title;
	}

	public double getRate() {
		return rate;
	}

	public int getNumberOfReviews() {
		return numberOfReviews;
	}

	public double getPrice() {
		return price;
	}

	//toString
	@Override
	public String toString() {
		return "Products is: [id=" + id + ", title=" + title + ", rate=" + rate + ", numberOfReviews="
				+ numberOfReviews + ", price=" + price + "]";
	}
	
	
	
	
	
	
	
}
