
public class Sales {

	private int id; 
	private String customerID; 
	private String productID; 
	private String salesDate;
	private double salesPrice;
	
	
	
	//default constructor
	public Sales() {
		id = 0;
		customerID = "";
		productID = "";
		salesDate = "";
	}
	
	//defined constructor
	public Sales(int id, String customerID, String productID, String salesDate) {
		this.id = id;
		this.customerID = customerID;
		this.productID = productID;
		this.salesDate = salesDate;
		
	}
	
	public int getId() {
		return id;
	}

	public String getCustomerID() {
		return customerID;
	}

	public String getProductID() {
		return productID;
	}

	public String getSalesDate() {
		return salesDate;
	}

	public double getSalesPrice() {
		return salesPrice;
	}

	//toString
	@Override
	public String toString() {
		return "Sales [id=" + id + ", customerID=" + customerID + ", productID=" + productID + ", salesDate="
				+ salesDate + ", salesPrice=" + salesPrice + "]";
	}
		
	
	
	
	
	
}
