

import java.io.*;
import java.util.StringTokenizer;

import javax.print.DocFlavor.URL;

public class JavaIOFile {

	/*
	 * JavaIOFile class reads a given .csv file and then creates the given classes (customer,product,sale)
	 * which will be later used on our program.
	 */
	public static Customer[] readAndCreateCustomers(File file) throws IOException {
		
		//Customer counter is "-1" because we want to omit the title section.
		int customerCounter = -1;
		//Element tracker to be used in the customer array
		int arrayElementTracker = 0;
				
		String customerFileLine = "";
		
		BufferedReader reader0 = new BufferedReader(new FileReader (file));
		while(reader0.readLine() != null) {
			customerCounter++;
		}
		
		Customer[] customerArray = new Customer[customerCounter];
		
		BufferedReader reader = new BufferedReader(new FileReader (file));
		//to skip the titles: ID,Name,Email,Country,Address
		reader.readLine();
		
		while(customerCounter != 0) {
			customerFileLine = reader.readLine();
			StringTokenizer tkn = new StringTokenizer(customerFileLine,",");
			
			customerArray[arrayElementTracker] =new Customer(tkn.nextToken(), tkn.nextToken(), tkn.nextToken(), tkn.nextToken(), tkn.nextToken());
			
			arrayElementTracker ++;
			customerCounter--;
			
		}
		
		reader0.close();
		reader.close();
		
		return customerArray;
	}
	
	public static Product[] readAndCreateProducts(File file) throws IOException{
			//Products counter is "-1" because we want to omit the title section.
			int productsCounter = -1;
				
			int arrayElementTracker = 0;
						
			String productsFileLine = "";
				
			BufferedReader reader0 = new BufferedReader(new FileReader (file));
			while(reader0.readLine() != null) {
				productsCounter++;
			}
				
			Product[] productArray = new Product[productsCounter];
				
			BufferedReader reader = new BufferedReader(new FileReader (file));
			//to skip the titles: ID,title,rate,number of reviews,price
			reader.readLine();
				
			while(productsCounter != 0) {
				productsFileLine = reader.readLine();
				StringTokenizer tkn = new StringTokenizer(productsFileLine,",");
					
				productArray[arrayElementTracker] =new Product(tkn.nextToken(), tkn.nextToken(), Double.parseDouble(tkn.nextToken()), Integer.parseInt(tkn.nextToken()), Double.parseDouble(tkn.nextToken()));
					
				arrayElementTracker ++;
				productsCounter--;
					
			}
				
			reader0.close();
			reader.close();
				
			return productArray;
	}
	
	public static Sales[] readAndCreateSales(File file) throws IOException {
		//Sales counter is "-1" because we want to omit the title section.
		int salesCounter = -1;
		int arrayElementTracker = 0;
		String salesFileLine = "";	
		
		BufferedReader reader0 = new BufferedReader(new FileReader (file));
		while(reader0.readLine() != null) {
			salesCounter++;
		}
		Sales[] salesArray = new Sales[salesCounter];
		
		BufferedReader reader = new BufferedReader(new FileReader (file));
		//to skip the titles: ID,customer id, product id,sales date
		reader.readLine();
			
		while(salesCounter != 0) {
			salesFileLine = reader.readLine();
			StringTokenizer tkn = new StringTokenizer(salesFileLine,",");
				
			salesArray[arrayElementTracker] =new Sales(Integer.parseInt(tkn.nextToken()), tkn.nextToken(), tkn.nextToken(), tkn.nextToken());
				
			arrayElementTracker ++;
			salesCounter--;
				
		}
			
		reader0.close();
		reader.close();
			
		return salesArray;
	}
	
}
