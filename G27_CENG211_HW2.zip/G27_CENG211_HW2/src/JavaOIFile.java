import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class JavaOIFile {

	public static ArrayList<Vehicle> readAndCreateVehicles(File file) throws IOException {
		
		/*
		 * This is our IO file which we use to read the .csv file and
		 * create the wanted vehicles using a switch.
		 */
		
		int vehicleCounter = 0;			
		String vehicleFileLine = "";
		
		BufferedReader reader0 = new BufferedReader(new FileReader (file));
		while(reader0.readLine() != null) {
			vehicleCounter++;
		}
		
		ArrayList<Vehicle> vehicleArrayList = new ArrayList<Vehicle>();
		
		BufferedReader reader = new BufferedReader(new FileReader (file));
	
		
		while(vehicleCounter != 0) {
			vehicleFileLine = reader.readLine();
			StringTokenizer tkn = new StringTokenizer(vehicleFileLine,",");
			
			String vehicleID = tkn.nextToken();
			char vehicleType = vehicleID.charAt(0);
			
			//We create vehicles according the their first character of vehicle ID.
			switch(vehicleType) {
			case 'S':
				vehicleArrayList.add(new Sedan(vehicleID, tkn.nextToken(), tkn.nextToken(), Integer.parseInt(tkn.nextToken()), tkn.nextToken(), Double.parseDouble(tkn.nextToken()), Integer.parseInt(tkn.nextToken())));
				break;
			case 'H':
				vehicleArrayList.add(new Hatchback(vehicleID, tkn.nextToken(), tkn.nextToken(), Integer.parseInt(tkn.nextToken()), tkn.nextToken(), Double.parseDouble(tkn.nextToken()), Integer.parseInt(tkn.nextToken())));
				break;
			case 'M':
				vehicleArrayList.add(new Minivan(vehicleID, tkn.nextToken(), tkn.nextToken(), Integer.parseInt(tkn.nextToken()), Integer.parseInt(tkn.nextToken()), Double.parseDouble(tkn.nextToken()), Integer.parseInt(tkn.nextToken())));
				break;

			case 'P':
				vehicleArrayList.add(new PickupTruck(vehicleID, tkn.nextToken(), tkn.nextToken(), Integer.parseInt(tkn.nextToken()), tkn.nextToken(), tkn.nextToken(), Integer.parseInt(tkn.nextToken())));
				break;

			case 'B':
				vehicleArrayList.add(new Bicycle(vehicleID, tkn.nextToken(), tkn.nextToken(), Integer.parseInt(tkn.nextToken()), tkn.nextToken(), tkn.nextToken(), Integer.parseInt(tkn.nextToken())));
				break;

			
			}
			
			vehicleCounter--;
			
		}
		
		reader0.close();
		reader.close();
		
		return vehicleArrayList;
	}
	
}
