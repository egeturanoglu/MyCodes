
public class Sedan extends Automobile{

	private String roofType;

	//Default Constructor
	public Sedan() {
		super();
		this.roofType = "";
	}

	//Defined Constructor
	public Sedan(String vehicleID, String monthOfSale, String cityOfSale, int productionYear,String roofType,double engineVolume, int vat
			) {
		super(vehicleID, monthOfSale, cityOfSale, productionYear, engineVolume, vat);
		this.roofType = roofType;
	}
	
	//Copy Constructor
	public Sedan(Sedan otherSedan) {
		super(otherSedan);
		this.roofType = otherSedan.getRoofType();
	}

	public String getRoofType() {
		return roofType;
	}

	@Override
	public String toString() {
		return "Sedan [" + super.toString() + ", roofType=" + roofType + "]\n" + "Total price for " + getVehicleID() + " is:" + totalPrice() + "TL\n\n";
	}
	
	//Assign given roof type to it's SCT value
	private double assignRoofSCT() {
		double roofTypeSCT = 0;
		
		switch(roofType) {	
		case "regular":
			roofTypeSCT = 0.5;
			break;
		case "moonroof":
			roofTypeSCT = 0.6;
			break;
		case "sunroof":
			roofTypeSCT = 0.8;
			break;
		default:
			roofTypeSCT = 0;
		}
		
		return roofTypeSCT;
	}
	
	
	//calculate total sct of sedan.
	public double calculateSCT() {
		double result = 0;
		result = result + ((getEngineVolume()*2*assignRoofSCT())/super.assigYearSCT());	
		return result;
	}
	
	//price of the given sedan object
	public double totalPrice() {
		double total = 0;
		total = total + (200000*(1+(calculateSCT()*0.8)) + (1+(super.getVat()/100)));
		System.out.println();
		return total;
		
	}

	
	
	
	
	
	
}
