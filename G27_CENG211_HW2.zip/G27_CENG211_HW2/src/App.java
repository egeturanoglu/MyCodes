
public class App {
	public static void main(String[] args) {
		
		/*
		 * This is our App(main) class where we call and 
		 * test our methods as well as creating necessary objects. 
		 */
		
		SalesRecord sales = new SalesRecord();
		sales.userChoice();	
		
		
		
	}
	
}
