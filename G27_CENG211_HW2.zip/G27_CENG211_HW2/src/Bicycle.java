
public class Bicycle extends Vehicle{
	
	private String chainType;
	private String seatPost;
	
	//Default Constructor
	public Bicycle() {
		super();
		this.chainType = "";
		this.seatPost = "";
	}
	
	//Defined Constructor
	public Bicycle(String vehicleID, String monthOfSale, String cityOfSale, int productionYear,String chainType,String seatPost, int vat) {
		super(vehicleID, monthOfSale, cityOfSale, productionYear, vat);
		this.chainType = chainType;
		this.chainType = seatPost;
	}
	
	//Copy Constructor
	public 	Bicycle(Bicycle otherBicycle) {
		super(otherBicycle);
		this.chainType = otherBicycle.getChainType();
		this.seatPost = otherBicycle.getSeatPost();
		}

	public String getChainType() {
		return chainType;
	}

	public String getSeatPost() {
		return seatPost;
	}

	@Override
	public String toString() {
		return "Bicycle [" + super.toString() + ", chainType=" + chainType + ", seatPost=" + seatPost + "]\n" + "Total price for " + getVehicleID() + " is:" + totalPrice() + "TL\n\n";
	}
	
	//Assign given chain type to it's SCT value
	private double assignChainTypeSCT() {
		double chainTypeSCT = 0;
		
		switch(chainType) {	
		case "derailleurr":
			chainTypeSCT = 1.1;
			break;
		case "onechain":
			chainTypeSCT = 1.2;
			break;
		case "doublechain":
			chainTypeSCT = 1.3;
			break;
		default:
			chainTypeSCT = 0;
		}
		
		return chainTypeSCT;
	}
	
	//Assign given seat post type to it's SCT value
	private double assignSeatPostSCT() {
		double seatPostSCT = 0;
		
		switch(chainType) {	
		case "carbonfiber":
			seatPostSCT = 0.8;
			break;
		case "steel":
			seatPostSCT = 0.7;
			break;
		case "aluminum":
			seatPostSCT = 0.9;
			break;
		case "titanium":
			seatPostSCT = 0.6;
			break;
		default:
			seatPostSCT = 0;
		}
		
		return seatPostSCT;
	}
	
	//calculate total sct of bicycle.
	public double calculateSCT() {
		double result = 0;
		result = result +  ((assignChainTypeSCT() *assignSeatPostSCT()*0.1) / (super.assignMonthfSCT()));	
		return result;
	}
	
	//price of the given pickup bicycle.
	public double totalPrice() {
		double total = 0;
		total = total + (10000*0.9*(1+calculateSCT()) + (1+(super.getVat()/100)));
		System.out.println();
		return total;
		
	}
	

}
