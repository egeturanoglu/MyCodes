
public class Hatchback extends Automobile{
	
	private String cityMode;

	//Defined Constructor
	public Hatchback() {
		super();
		this.cityMode = "";
	}
	
	//Default Constructor
	public Hatchback(String vehicleID, String monthOfSale, String cityOfSale, int productionYear,String cityMode, double engineVolume,
			int vat) {
		super(vehicleID, monthOfSale, cityOfSale, productionYear, engineVolume, vat);
		this.cityMode = cityMode;
	}

	public String getCityMode() {
		return cityMode;
	}
	
	//Copy Constructor
	public 	Hatchback(Hatchback otherHatchback) {
		super(otherHatchback);
		this.cityMode = otherHatchback.getCityMode();
	}

	@Override
	public String toString() {
		return "Hatchback [" + super.toString() + ", cityMode=" + cityMode + "]\n" + "Total price for " + getVehicleID() + " is:" + totalPrice() + "TL\n\n";
	}
	
	//Assign given city mode to it's SCT value
	private double assignCityModeSCT() {
		double cityModeSCT = 0;
		
		switch(cityMode) {	
		case "yes":
			cityModeSCT = 0.15;
			break;
		case "no":
			cityModeSCT = 0.1;
			break;
		default:
			cityModeSCT = 0;
		}
		
		return cityModeSCT;
	}
	
	//calculate total sct of hatchback.
	public double calculateSCT() {
		double result = 0;
		result = result + ((getEngineVolume()*0.3*super.assigYearSCT())+assignCityModeSCT());	
		return result;
	}
	
	//price of the given hatchback object
	public double totalPrice() {
		double total = 0;
		total = total + (200000*(1+(calculateSCT()*0.8)) + (1+(super.getVat()/100)));
		System.out.println();

		return total;
		
	}

	
	
	
	
}
