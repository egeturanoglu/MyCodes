import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class SalesRecord {
	
	/*
	 * this is our SalesRecord class which holds 
	 * the methods which we will use to see the lists of sold vehicles etc.
	 * The class reads the .csv file and creates a vehicle list to use.
	 * At the end of the class we have an user choice method to take an 
	 * input from the user and use the input to display a method.
	 */
	
	private File soldVehiclesFile;
	private ArrayList<Vehicle> vehicleList;
	
	//Constructor
	public SalesRecord() {
		this.soldVehiclesFile = new File("src/HW2_SoldVehicles.csv");
		try {
			vehicleList = JavaOIFile.readAndCreateVehicles(soldVehiclesFile);
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
		
	public ArrayList<Vehicle> getVehicleList() {
		return vehicleList;
	}

	
	
	private static  ArrayList<Vehicle> soldVehicles(ArrayList<Vehicle> arrList){
		System.out.println("All of the sold vehicles are: ");
		return arrList;
	}
	
	private static ArrayList<Vehicle> soldSedan(ArrayList<Vehicle> arrList){
		
		ArrayList<Vehicle> sedanList = new ArrayList<Vehicle>();
		
		for(int i = 0; i<arrList.size(); i++) {
			if(arrList.get(i).getVehicleID().charAt(0) == 'S' ) {
				sedanList.add(arrList.get(i));

			}
		}
		
		System.out.println("All of the sold sedans are: ");
		return sedanList;
		
	}
	
	private static ArrayList<Vehicle> soldHatchback(ArrayList<Vehicle> arrList){
		
		ArrayList<Vehicle> hatchbackList = new ArrayList<Vehicle>();
		
		for(int i = 0; i<arrList.size(); i++) {
			if(arrList.get(i).getVehicleID().charAt(0) == 'H' ) {
				hatchbackList.add(arrList.get(i));
			}
		}
		
		System.out.println("All of the sold hatchbacks are: ");
		return hatchbackList;		
	}
	
	private static ArrayList<Vehicle> soldMinivan(ArrayList<Vehicle> arrList){
		
		ArrayList<Vehicle> minivanList = new ArrayList<Vehicle>();
		
		for(int i = 0; i<arrList.size(); i++) {
			if(arrList.get(i).getVehicleID().charAt(0) == 'M' ) {
				minivanList.add(arrList.get(i));
			}
		}
		
		System.out.println("All of the sold minivans are: ");
		return minivanList;		
	}
	
	private static ArrayList<Vehicle> soldPickupTruck(ArrayList<Vehicle> arrList){
		
		ArrayList<Vehicle> pickupList = new ArrayList<Vehicle>();
		
		for(int i = 0; i<arrList.size(); i++) {
			if(arrList.get(i).getVehicleID().charAt(0) == 'P' ) {
				pickupList.add(arrList.get(i));
			}
		}
		
		System.out.println("All of the sold pickup trucks are: ");
		return pickupList;		
	}
	
	private static ArrayList<Vehicle> soldBicycle(ArrayList<Vehicle> arrList){
		
		ArrayList<Vehicle> bicycleList = new ArrayList<Vehicle>();
		
		for(int i = 0; i<arrList.size(); i++) {
			if(arrList.get(i).getVehicleID().charAt(0) == 'B' ) {
				bicycleList.add(arrList.get(i));
			}
		}
		
		System.out.println("All of the sold bicycles are: ");
		return bicycleList;		
	}	
	
	public void userChoice() {
		int userChoice = -1;
		Scanner scan = new Scanner(System.in);
		System.out.println("Press 1 to see all sold vehicles list. \n"
				+ "Press 2 to see sold sedan list. \n"
				+ "Press 3 to see sold hatchback list. \n"
				+ "Press 4 to see sold minivan list. \n"
				+ "Press 5 to see sold pickup truck list. \n"
				+ "Press 6 to see sold bicycle list.");
		System.out.println("Your choice: ");
		
		while(userChoice < 1 || userChoice >6 ) {
			userChoice = scan.nextInt();
		}
		System.out.println();
		switch(userChoice){
		case 1:
			System.out.println(soldVehicles(getVehicleList()));
			break;
		case 2:
			System.out.println(soldSedan(getVehicleList()));;
			break;
		case 3:
			System.out.println(soldHatchback(getVehicleList()));;
			break;
		case 4:
			System.out.println(soldMinivan(getVehicleList()));;
			break;
		case 5:
			System.out.println(soldPickupTruck(getVehicleList()));;
			break;
		case 6:
			System.out.println(soldBicycle(getVehicleList()));;
			break;
		default:
			System.out.println("ERROR");
		}

		scan.close();
	}
}
