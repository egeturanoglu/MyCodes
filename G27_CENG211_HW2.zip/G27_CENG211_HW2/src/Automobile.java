
public class Automobile extends Vehicle{

	private double engineVolume;

	//Default Constructor
	public Automobile() {
		super();
		this.engineVolume = 0;
	}

	//Defined Constructor
	public Automobile(String vehicleID, String monthOfSale, String cityOfSale, int productionYear,double engineVolume, int vat) {
		super(vehicleID, monthOfSale, cityOfSale, productionYear, vat);
		this.engineVolume = engineVolume;
	}
	
	//Copy Constructor
	public Automobile(Automobile otherAutomobile) {
		super(otherAutomobile);
		this.engineVolume = otherAutomobile.getEngineVolume();
	}

	public double getEngineVolume() {
		return engineVolume;
	}
 
	@Override
	public String toString() {
		return "Automobile [" + super.toString() + ", engine volume=" + engineVolume + "]";
	}
	
	
	
	
	
}
