
public class Minivan extends Automobile{
	
	private int numberOfSeats;

	//Default Constructor
	public Minivan() {
		super();
		this.numberOfSeats = 0;
	}

	//Default Constructor
	public Minivan(String vehicleID, String monthOfSale, String cityOfSale, int productionYear,int numberOfSeats, double engineVolume,
			int vat) {
		super(vehicleID, monthOfSale, cityOfSale, productionYear, engineVolume, vat);
		this.numberOfSeats = numberOfSeats;
	}

	public int getNumberOfSeats() {
		return numberOfSeats;
	}
	
	//Copy Constructor
	public 	Minivan(Minivan otherMinivan) {
		super(otherMinivan);
		this.numberOfSeats = otherMinivan.getNumberOfSeats();
	}

	@Override
	public String toString() {
		return "Minivan [" + super.toString() + ", numberOfSeats=" + numberOfSeats + "]\n" + "Total price for " + getVehicleID() + " is:" + totalPrice() + "TL\n\n";
	}
	
	//Assign given number of seats to it's SCT value
		private double assignSeatNumSCT() {
			double seatNumSCT = 0;
			
			switch(numberOfSeats) {	
			case 4:
				seatNumSCT = 0.1;
				break;
			case 5:
				seatNumSCT = 0.4;
				break;
			case 6:
				seatNumSCT = 0.6;
				break;
			case 7:
				seatNumSCT = 0.8;
				break;
			default:
				seatNumSCT = 0;
			}
			
			return seatNumSCT;
		}
		
		//calculate total sct of minivan.
		public double calculateSCT() {
			double result = 0;
			result = result +  ((0.6 * super.assigYearSCT())/(getEngineVolume()+ assignSeatNumSCT()));	
			return result;
		}
		
		//price of the given minivan object
		public double totalPrice() {
			double total = 0;
			total = total + (200000*(1+(calculateSCT()*0.8)) + (1+(super.getVat()/100)));
			System.out.println();
			return total;
			
		}
	
	
	
	
	

}
