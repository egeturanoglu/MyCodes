
public class Vehicle {

	private String vehicleID;
	private String monthOfSale;
	private String cityOfSale;
	private int productionYear;
	private int vat;
	
	//Default Constructor
		public Vehicle() {
			this.vehicleID = "";
			this.monthOfSale = "";
			this.cityOfSale = "";
			this.productionYear = 0;
			this.vat = 0;
		}
	
	//Defined Constructor
	public Vehicle(String vehicleID, String monthOfSale, String cityOfSale, int productionYear, int vat) {
		this.vehicleID = vehicleID;
		this.monthOfSale = monthOfSale;
		this.cityOfSale = cityOfSale;
		this.productionYear = productionYear;
		this.vat = vat;
	}
	
	//Copy Constructor
	public Vehicle(Vehicle otherVehicle) {
		this.vehicleID = otherVehicle.getVehicleID();
		this.monthOfSale = otherVehicle.getMonthOfSale();
		this.cityOfSale = otherVehicle.getCityOfSale();
		this.productionYear = otherVehicle.getProductionYear();
		this.vat = otherVehicle.getVat();
	}

	public String getVehicleID() {
		return vehicleID;
	}

	public String getMonthOfSale() {
		return monthOfSale;
	}

	public String getCityOfSale() {
		return cityOfSale;
	}

	public int getProductionYear() {
		return productionYear;
	}

	public int getVat() {
		return vat;
	}

	@Override
	public String toString() {
		return "Vehicle [vehicleID=" + vehicleID + ", monthOfSale=" + monthOfSale + ", cityOfSale=" + cityOfSale
				+ ", productionYear=" + productionYear + ", vat=" + vat + "]";
	}
	
	
	//Assign given month of sale to it's SCT value
		double assignMonthfSCT() {
			double monthOfSaleSCT = 0;
			
			switch(monthOfSale) {	
			case "January":
				monthOfSaleSCT = 0.3;
				break;
			case "May":
				monthOfSaleSCT = 0.4;
				break;
			case "August":
				monthOfSaleSCT = 0.5;
				break;
			case "October":
				monthOfSaleSCT = 0.6;
				break;
			case "December":
				monthOfSaleSCT = 0.7;
				break;
			default:
				monthOfSaleSCT = 0;
			}
			
			return monthOfSaleSCT;
		}
		
	
		//Assign given city of sale to it's SCT value
		double assigCitySCT() {
			double cityOfSaleSCT = 0;
			
			switch(cityOfSale) {	
			case "Izmir":
				cityOfSaleSCT = 0.1;
				break;
			case "Istanbul":
				cityOfSaleSCT = 0.3;
				break;
			case "August":
				cityOfSaleSCT = 0.2;
				break;
			default:
				cityOfSaleSCT = 0;
			}
			
			return cityOfSaleSCT;
		}
		
		//Assign given production year  to it's SCT value
		 double assigYearSCT() {
			double productionYearSCT = 0;
			
			if(2001<= productionYear && productionYear <= 2008) {
				productionYearSCT = 1.0;
			}
			else if(2012<= productionYear && productionYear <= 2017) {
				productionYearSCT = 1.2;
			}
			else if(2018<= productionYear && productionYear <= 2022) {
				productionYearSCT = 1.6;
			}
			else {
				productionYearSCT = 0;
			}
			
			return productionYearSCT;
		}
	
	
}
