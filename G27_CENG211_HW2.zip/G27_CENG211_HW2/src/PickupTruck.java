
public class PickupTruck extends Vehicle{
	
	private String cabType;
	private String truckBedType;
	
	//Default Constructor
	public PickupTruck() {
		super();
		this.cabType = "";
		this.truckBedType = "";
	}
	
	//Defined Constructor
	public PickupTruck(String vehicleID, String monthOfSale, String cityOfSale, int productionYear,String cabType,String truckBedType, int vat) {
		super(vehicleID, monthOfSale, cityOfSale, productionYear, vat);
		this.cabType = cabType;
		this.truckBedType = truckBedType;
	}

	//Copy Constructor
	public 	PickupTruck(PickupTruck otherPickupTruck) {
		super(otherPickupTruck);
		this.cabType = otherPickupTruck.getCabType();
		this.truckBedType = otherPickupTruck.getTruckBedType();
	}
	
	public String getCabType() {
		return cabType;
	}

	public String getTruckBedType() {
		return truckBedType;
	}

	@Override
	public String toString() {
		return "PickupTruck ["+ super.toString() + ", cabType=" + cabType + ", truckBedType=" + truckBedType +
				"]\n" + "Total price for " + getVehicleID() + " is:" + totalPrice() + "TL\n\n";
	}
	
	//Assign given cab type to it's SCT value
	private double assignCabTypeSCT() {
		double cabTypeSCT = 0;
		
		switch(cabType) {	
		case "regular":
			cabTypeSCT = 2.5;
			break;
		case "extended":
			cabTypeSCT = 2.8;
			break;
		case "crew":
			cabTypeSCT = 3.0;
			break;
		default:
			cabTypeSCT = 0;
		}
		
		return cabTypeSCT;
	}
	
	//Assign given bed type to it's SCT value
	private double assignBedTypeSCT() {
		double bedTypeSCT = 0;
		
		switch(truckBedType) {	
		case "regular":
			bedTypeSCT = 2.5;
			break;
		case "tanker":
			bedTypeSCT = 2.8;
			break;
		case "trailer":
			bedTypeSCT = 3.0;
			break;
		default:
			bedTypeSCT = 0;
		}
		
		return bedTypeSCT;
	}
		
	//calculate total sct of pickup truck.
	public double calculateSCT() {
		double result = 0;
		result = result +  ((assignBedTypeSCT() *super.assigYearSCT())/(assignCabTypeSCT()));	
		return result;
	}
	
	//price of the given pickup truck object
	public double totalPrice() {
		double total = 0;
		total = total + (250000*(1+(calculateSCT()*0.6)) + (1+(super.getVat()/100)));
		System.out.println();
		return total;
		
	}

}
